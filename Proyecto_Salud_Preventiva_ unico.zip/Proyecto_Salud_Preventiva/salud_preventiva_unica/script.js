/* Salud Preventiva - Prototipo académico de frontend. No usar datos reales. */
'use strict';
let currentRole='paciente', stream=null, consultationStart=null, timer=null, pdfUrl=null, selectedPdf=null;
const $=id=>document.getElementById(id);
const getAppointments=()=>{try{return JSON.parse(sessionStorage.getItem('demoAppointments')||'[]')}catch{return []}};
const setAppointments=items=>sessionStorage.setItem('demoAppointments',JSON.stringify(items));
function navigateTo(id){
 if(!$(id))return;
 if(id==='view-login'){endConsultation();sessionStorage.removeItem('demoSession');}
 document.querySelectorAll('.view-section').forEach(el=>el.classList.toggle('active',el.id===id));
 $('main-header')?.classList.toggle('hidden',['view-login','view-register','view-forgot-password','view-forgot-confirm'].includes(id));
 if(id==='view-agenda')renderAgenda();
 window.scrollTo(0,0);
 if(window.lucide)lucide.createIcons();
}
function navigateToDashboard(){navigateTo(currentRole==='medico'?'view-doctor-dashboard':'view-patient-dashboard')}
function selectLoginRole(role){currentRole=role==='medico'?'medico':'paciente';
 ['patient','doctor'].forEach(x=>{let el=$('role-'+x+'-card');if(el)el.style.outline=(x===(currentRole==='medico'?'doctor':'patient'))?'2px solid #0284c7':'none'});
}
function toggleRole(){currentRole=currentRole==='medico'?'paciente':'medico';updateRole();navigateToDashboard()}
function updateRole(){if($('role-label'))$('role-label').textContent=currentRole==='medico'?'Médico':'Paciente'}
function handleLogin(e){e.preventDefault();const email=$('login-email').value.trim();const password=$('login-password').value;
 if(!email||password.length<6){alert('Escribe un correo válido y una contraseña de al menos 6 caracteres.');return}
 const account=JSON.parse(sessionStorage.getItem('demoAccount')||'null');
 if(account&&(account.email!==email||account.password!==password)){alert('Los datos no coinciden con el registro de demostración.');return}
 sessionStorage.setItem('demoSession',email);updateRole();navigateToDashboard();
}
function handleRegister(e){e.preventDefault();const name=$('register-name').value.trim(),email=$('register-email').value.trim(),doc=$('register-document').value.trim(),phone=$('register-phone').value.trim();
 if(name.length<3||!/^\S+@\S+\.\S+$/.test(email)||!/^\d{5,15}$/.test(doc)||!/^\+?[\d\s-]{7,18}$/.test(phone)){alert('Revisa el nombre, correo, documento (solo números) y teléfono.');return}
 sessionStorage.setItem('demoAccount',JSON.stringify({name,email,password:'demo123'}));alert('Registro de demostración creado. Para ingresar utiliza la contraseña temporal demo123. No uses datos reales.');$('login-email').value=email;$('login-password').value='';navigateTo('view-login');
}
function handleForgotPassword(e){e.preventDefault();navigateTo('view-forgot-confirm')}
function parseDate(value){const m=/^(\d{2})\/(\d{2})\/(\d{4})$/.exec(value.trim());if(!m)return null;const d=new Date(+m[3],+m[2]-1,+m[1]);return d.getFullYear()===+m[3]&&d.getMonth()===+m[2]-1&&d.getDate()===+m[1]?d:null}
function handleAppointment(e){e.preventDefault();const type=$('appointment-type'),time=$('appointment-time'),date=parseDate($('appointment-date').value);const today=new Date();today.setHours(0,0,0,0);
 if(!date||date<today){alert('Ingresa una fecha válida, de hoy en adelante, en formato DD/MM/AAAA.');$('appointment-date').focus();return}
 if(!type.value||!time.value){alert('Selecciona el tipo de consulta y la hora.');return}
 const dateText=$('appointment-date').value, typeText=type.options[type.selectedIndex].text,timeText=time.options[time.selectedIndex].text;
 const items=getAppointments();if(items.some(a=>a.date===dateText&&a.time===time.value)){alert('Ya tienes una cita de demostración para esa fecha y hora.');return}
 items.push({date:dateText,time:time.value,timeText,type:typeText});setAppointments(items);
 $('confirmation-date').textContent=dateText;$('confirmation-time').textContent=timeText;$('confirmation-type').textContent=typeText;navigateTo('view-appointment-confirm');e.target.reset();
}
function renderAgenda(){const el=$('agenda-list');if(!el)return;const items=getAppointments();
 const old=$('demo-appointments');if(old)old.remove();const wrapper=document.createElement('div');wrapper.id='demo-appointments';wrapper.className='p-5 bg-sky-50';
 const title=document.createElement('h3');title.className='font-bold text-sky-900 mb-3';title.textContent='Mis citas de demostración';wrapper.append(title);
 if(!items.length){const p=document.createElement('p');p.textContent='Todavía no has agendado citas en esta sesión.';wrapper.append(p)}
 items.forEach((a,i)=>{const line=document.createElement('div');line.className='flex flex-wrap justify-between items-center gap-2 py-2 border-t border-sky-100';const span=document.createElement('span');span.textContent=`${a.date} · ${a.timeText} · ${a.type}`;const btn=document.createElement('button');btn.textContent='Cancelar';btn.className='text-red-600 underline';btn.addEventListener('click',()=>{const updated=getAppointments();updated.splice(i,1);setAppointments(updated);renderAgenda()});line.append(span,btn);wrapper.append(line)});
 el.prepend(wrapper);
}
function syncDateInput(){const picker=$('appointment-date-picker'),input=$('appointment-date');if(!picker||!input)return;picker.addEventListener('change',()=>{if(picker.value){const [y,m,d]=picker.value.split('-');input.value=`${d}/${m}/${y}`}});input.addEventListener('input',()=>{let v=input.value.replace(/\D/g,'').slice(0,8);if(v.length>4)v=v.slice(0,2)+'/'+v.slice(2,4)+'/'+v.slice(4);else if(v.length>2)v=v.slice(0,2)+'/'+v.slice(2);input.value=v});input.placeholder='DD/MM/AAAA';picker.min=new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,10)}
async function toggleCamera(){if(stream?.getVideoTracks().length){stream.getVideoTracks().forEach(t=>t.stop());stream=null;$('videoConsulta').srcObject=null;$('videoConsulta').classList.add('hidden');$('videoPlaceholder').classList.remove('hidden');$('btnCamara').textContent='📷 Encender cámara';return}
 try{const s=await navigator.mediaDevices.getUserMedia({video:true,audio:false});stream=s;$('videoConsulta').srcObject=s;$('videoConsulta').classList.remove('hidden');$('videoPlaceholder').classList.add('hidden');$('btnCamara').textContent='📷 Apagar cámara';$('consultaStatus').textContent='Vista previa local de cámara activa. No hay conexión con otro usuario.'}catch{$('consultaStatus').textContent='No se pudo activar la cámara. Revisa permisos y usa localhost o HTTPS.'}}
async function toggleMicrophone(){if(stream?.getAudioTracks().length){stream.getAudioTracks().forEach(t=>t.stop());$('btnMicrofono').textContent='🎤 Activar micrófono';return}
 try{const audio=await navigator.mediaDevices.getUserMedia({audio:true});if(stream){audio.getAudioTracks().forEach(t=>stream.addTrack(t))}else{stream=audio}$('btnMicrofono').textContent='🎤 Desactivar micrófono';$('consultaStatus').textContent='Micrófono local activo; no se transmite audio.'}catch{$('consultaStatus').textContent='No se pudo activar el micrófono. Revisa los permisos.'}}
function startConsultation(){if(timer)return;consultationStart=Date.now();$('consultaTimer').classList.remove('hidden');$('consultaStatus').textContent='Simulación de consulta iniciada (sin conexión médica real).';timer=setInterval(()=>{const seconds=Math.floor((Date.now()-consultationStart)/1000);$('consultaTimer').textContent=`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`},1000)}
function endConsultation(){if(timer)clearInterval(timer);timer=null;if(stream){stream.getTracks().forEach(t=>t.stop());stream=null}if($('videoConsulta')){$('videoConsulta').srcObject=null;$('videoConsulta').classList.add('hidden')};$('videoPlaceholder')?.classList.remove('hidden');$('consultaTimer')?.classList.add('hidden');if($('consultaTimer'))$('consultaTimer').textContent='00:00';if($('btnCamara'))$('btnCamara').textContent='📷 Encender cámara';if($('btnMicrofono'))$('btnMicrofono').textContent='🎤 Activar micrófono';if($('consultaStatus'))$('consultaStatus').textContent='Sesión finalizada. Simulación local.'}
function selectResultPdf(e){selectedPdf=e.target.files?.[0]||null;if($('pdfStatus'))$('pdfStatus').textContent=selectedPdf?(selectedPdf.type==='application/pdf'?'PDF seleccionado: '+selectedPdf.name:'Selecciona un archivo PDF válido.'):'Ningún archivo seleccionado.'}
function viewResultPdf(){if(!selectedPdf||selectedPdf.type!=='application/pdf'){alert('Selecciona primero un archivo PDF.');return}closeResultPdf();pdfUrl=URL.createObjectURL(selectedPdf);$('pdfPreview').src=pdfUrl;$('pdfPreviewTitle').textContent=selectedPdf.name;$('pdfPreviewContainer').classList.remove('hidden')}
function closeResultPdf(){$('pdfPreviewContainer')?.classList.add('hidden');if($('pdfPreview'))$('pdfPreview').removeAttribute('src');if(pdfUrl)URL.revokeObjectURL(pdfUrl);pdfUrl=null}
document.addEventListener('DOMContentLoaded',()=>{selectLoginRole('paciente');updateRole();syncDateInput();if(window.lucide)lucide.createIcons();});
